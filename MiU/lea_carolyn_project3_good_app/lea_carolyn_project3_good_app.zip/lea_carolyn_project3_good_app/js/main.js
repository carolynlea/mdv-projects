var currentDate = new Date();  
$("#mydate").datepicker("setDate",currentDate);
